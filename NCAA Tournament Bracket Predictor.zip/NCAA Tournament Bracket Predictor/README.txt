NCAA MEN'S COLLEGE BASKETBALL BRACKET PREDICTOR

---------------------------------------------
WHAT IT IS

Welcome to the NCAA Men's College Basketball Bracket Predictor program. This program takes a .txt file that contains the NCAA tournament field and fills out the bracket for you. You can do this by yourself, or you can do it with this simulation. In order to make this bracket as realistic as possible, the following website was used for the simulations:

http://mcubed.net/ncaab/seeds.shtml

---------------------------------------------
HOW IT WORKS

I took the win percentage for each seed vs seed matchup. For teams that had a 100% win percentage against another seed with less than 5 games played, the chance of each seed winning is 50-50. The 1 vs 16 matchup has the 1 seed having a 99.9% chance to move on, as at some point in the future the 16 seed is going to win. If the seeds have never played before in history, then it's a toss up between the seeds. 

---------------------------------------------
WHAT'S INCLUDED

-The 2017 tournament file
-The NCAA Bracket Predictor Program

---------------------------------------------
CREATING TOURNAMENTS FILES AND RUNNING THEM

To create a tournament file:
1. Open a text editor
2. Enter the four regions for the tournament on the first four lines in all caps. Keep in mind this order.
	EX: EAST
	    WEST
	    MIDWEST
	    SOUTH
3. Enter the 16 seeds from the first region you entered. Make sure that two teams that play each other are next to each other. The easiest way to do this is simply to look at the complete bracket and run down from the top, one by one. DO NOT INCLUDE THEIR SEED, JUST THEIR NAME, THE SEEDS IN THE EXAMPLE ARE FOR ILLUSTRATION PURPOSES
	EX: Villanova (1)
	    Mount St. Mary's (16)
	    Wisconsin (8)
	    Virginia Tech (9)
	    Virginia (5)
	    UNC Wilmington (12)
            Florida (4)
	    East Tennessee State (13)
	    SMU (6)
	    USC (11)
	    Baylor (3)
	    New Mexico State (14)
	    South Carolina (7)
	    Marquette (10)
	    Duke (2)
	    Troy (15)
4. Do the same for the next 3 regions, do not add blank lines after each region.
5. Save the file wherever you want
6. Open the program
7. Click select file
8. Navigate to the saved file and open it
9. That's it! The program should display a simulated NCAA tournament! 

** Be sure to split each region and team onto SEPARATE lines with no blank lines in between
** For an example tournament file, look at 2017tournament.txt









For further questions or bug reports please email apkicklighter@gmail.com

©2018 Andrew Kicklighter

